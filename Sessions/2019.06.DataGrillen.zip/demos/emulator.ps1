# pull the emulator
# you need Docker configured for Windows containers
# docker pull microsoft/azure-cosmosdb-emulator

# how to run a container :
# https://hub.docker.com/r/microsoft/azure-cosmosdb-emulator/
# $Env:containerName = "azure-cosmosdb-emulator"
$Env:hostDirectory = $Env:LOCALAPPDATA + "\azure-cosmosdb-emulator.hostd"
$Env:hostDirectory
New-Item -ItemType directory -Force -Path $Env:hostDirectory
# docker run --name "azure-cosmosdb-emulator" --memory 2GB --mount "type=bind,source=%hostDirectory%,destination=C:\CosmosDB.Emulator\bind-mount" -P --interactive --tty microsoft/azure-cosmosdb-emulator
docker run --name "azure-cosmosdb-emulator" --memory 2GB --mount "type=bind,source=C:\Users\rudi\AppData\Local\azure-cosmosdb-emulator.hostd,destination=C:\CosmosDB.Emulator\bind-mount"  --interactive --tty -p 8081:8081 -p 8900:8900 -p 8901:8901 -p 8979:8979 -p 10250:10250 -p 10251:10251 -p 10252:10252 -p 10253:10253 -p 10254:10254 -p 10255:10255 -p 10256:10256 -p 10350:10350 microsoft/azure-cosmosdb-emulator

docker start "azure-cosmosdb-emulator"
docker rm "azure-cosmosdb-emulator"

docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' "azure-cosmosdb-emulator"

# cd $env:LOCALAPPDATA\CosmosDBEmulator\bind-mount
cd $Env:LOCALAPPDATA\azure-cosmosdb-emulator.hostd
.\importcert.ps1 # not in Powershell Core
# https://172.25.16.102:8081/_explorer/index.html

########################################################################
# we initialize a visual studio code project for the client application
########################################################################
New-Item -ItemType directory -Force -Path .\client
Set-Location client 
# dotnet new console

dotnet add package System.Net.Http
dotnet add package System.Configuration
dotnet add package System.Configuration.ConfigurationManager
dotnet add package Microsoft.Azure.DocumentDB.Core
dotnet add package Newtonsoft.Json
dotnet add package System.Threading.Tasks
dotnet add package System.Linq

# https://www.nuget.org/packages/Microsoft.EntityFrameworkCore.Cosmos/
dotnet add package Microsoft.EntityFrameworkCore.Cosmos --version 3.0.0-preview6.19304.10
dotnet restore