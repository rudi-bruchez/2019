using Newtonsoft.Json;

namespace client
{
    public interface IGrape
    {
        public string Id { get; set; }

        public decimal GrapeVarietyProportion { get; set; } 
        
        public string GrapeVariety { get; set; }

        public decimal SurfaceHa { get; set; } 
        
        public int Year { get; set; }
    }
}