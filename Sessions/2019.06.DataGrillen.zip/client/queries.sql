// https://public.opendatasoft.com/explore/dataset/wine-area-cepages-france/export/?flg=fr
SELECT w.fields 
FROM wines w

SELECT * 
FROM wines.fields f

SELECT f.grape_variety as grape
FROM wines.fields f

SELECT DISTINCT f.grape_variety as grape
FROM wines.fields f
ORDER BY f.grape_variety

SELECT * 
FROM Wines w
WHERE w.fields.surface_ha BETWEEN 600 AND 700

SELECT {"grape":w.fields.grape_variety, "year":w.fields.year} AS Grape 
FROM Wines w
WHERE w.fields.surface_ha BETWEEN 600 AND 700

SELECT DISTINCT f.year
FROM Wines w
JOIN w.fields f
ORDER BY f.year


SELECT w.fields.year, ARRAY(SELECT DISTINCT VALUE f.grape_variety FROM w.fields f) as grapes
FROM Wines w
ORDER BY w.fields.year

SELECT DISTINCT VALUE f.grape_variety FROM wines.fields f ORDER BY f.grape_variety 