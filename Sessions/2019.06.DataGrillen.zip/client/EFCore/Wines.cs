using Microsoft.EntityFrameworkCore.Cosmos;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace client.EFCore
{
    public class WinesDbContext : DbContext
    {
        public WinesDbContext(DbContextOptions options) : base(options)
    {
    }
        public DbSet<Wine> Wines { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Wine>();
            var Wines = modelBuilder.Entity<Wine>().Metadata;
            // Wines.CosmosSql().CollectionName = nameof(Wines);
        }
    }

    public class Wine
    {
        [Key]
        public string RecordId {get;set;}
        public decimal GrapeVarietyProportion { get; set; }
        public string GrapeVariety { get; set; }
        public decimal SurfaceHa { get; set; }
        public int Year { get; set; }
    }
}