﻿using System;
using System.Linq;

namespace client
{
    class Program
    {
        private enum ApiVersion
        {
            Version2,
            Version3
        }
        static void Main(string[] args)
        {
            ApiVersion apiVersion = ApiVersion.Version2;
            var l = Tools.ImportGrapes(@"./cepages-france.json");
            try
            {
                switch (apiVersion)
                {
                    case ApiVersion.Version2: 
                        var cc2 = new api_v2.MyCosmosClient("Wines", "Wines");
                        cc2.DeleteAllGrapes();
                        cc2.WriteGrapes(l.Cast<api_v2.Grape>().ToList());
                        break;
                    case ApiVersion.Version3:
                        var cc3 = new api_v3.MyCosmosClient("Wines", "Wines");
                        cc3.WriteGrapes(l.Cast<api_v3.Grape>().ToList());
                        break; 
                }
            }
            catch (Exception e)
            {
                Exception baseException = e.GetBaseException();
                Console.WriteLine("Error: {0}, Message: {1}", e.Message, baseException.Message);
            }
        }
    }
}
