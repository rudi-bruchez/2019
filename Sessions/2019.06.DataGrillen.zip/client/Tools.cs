using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Collections.Generic;

namespace client
{
    public static class Tools
    {
        public static List<IGrape> ImportGrapes(string jsonfile)
        {
            // var f = File.ReadAllText(jsonfile);
            var l = new List<IGrape>();

            JArray a = JArray.Parse(File.ReadAllText(jsonfile));
            foreach (var o in a)
            {
                IGrape g = o.ToObject<IGrape>();
                g.GrapeVarietyProportion = (decimal)o.SelectToken("fields.grape_variety_proportion");
                g.GrapeVariety = (string)o.SelectToken("fields.grape_variety");
                g.SurfaceHa = (decimal)o.SelectToken("fields.surface_ha");
                g.Year = (int)o.SelectToken("fields.year");

                l.Add(g);
            }

            return l;
        }
    }
}