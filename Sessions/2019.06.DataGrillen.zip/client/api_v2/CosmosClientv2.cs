using System;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace api_v2
{
    public class MyCosmosClient
    {
        private DocumentClient _client;
        private string _databaseName { get; set;}
        private string _containerName { get; set;}

        private string _documentLink
        {
            get
            {
                return $"dbs/{_databaseName}/colls/{_containerName}/";
            }
        }
        public MyCosmosClient(string databaseName, string containerName)
        {
            _databaseName = databaseName;
            _containerName = containerName;
            ConsistencyPolicy consistencyPolicy = new ConsistencyPolicy
            {
                DefaultConsistencyLevel = ConsistencyLevel.BoundedStaleness,
                MaxStalenessIntervalInSeconds = 5,
                MaxStalenessPrefix = 100
            };
            // Connect to the Azure Cosmos Emulator running locally
            this._client = new DocumentClient(
                new Uri("https://localhost:8081"),
                "C2y6yDjf5/R+ob0N8A7Cgv30VRDJIWEHLM+4QDU5DE2nQ9nDuVTqobD4b8mGGyPMbIZnqyMsEcaGQy67XIw/Jw==");
            this._client.OpenAsync().ConfigureAwait(false);

            this.InitializeDatabase()
        }

        private void InitializeDatabase()
        {
            try
            {
                this._client.CreateDatabaseIfNotExistsAsync(new Database { Id = this._databaseName });
                this._client.CreateDocumentCollectionIfNotExistsAsync(
                    UriFactory.CreateDatabaseUri(this._databaseName), 
                    new DocumentCollection { Id = this._containerName }
                    );
                Console.WriteLine("Database and collection validation complete");
            }
            catch (DocumentClientException de)
            {
                Exception baseException = de.GetBaseException();
                Console.WriteLine("{0} error occurred: {1}, Message: {2}", de.StatusCode, de.Message, baseException.Message);
            }

        }

        public void DeleteAllGrapes()
        {
            var grapes = this._client.CreateDocumentQuery(_documentLink)
                .AsEnumerable();
            foreach (var g in grapes)
            {
                Console.WriteLine(g.Id);
                this._client.DeleteDocumentAsync(g.SelfLink);
            }
        }

        public void WriteGrapes(List<Grape> grapes)
        {
            foreach (var g in grapes)
            {
                this._client.CreateDocumentAsync(
                    _documentLink,
                    g, null, true // disableAutomaticIdGeneration
                );
            }
        }
    }
}