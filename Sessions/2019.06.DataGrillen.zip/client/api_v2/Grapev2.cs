using Newtonsoft.Json;

namespace api_v2
{
    public class Grape : Microsoft.Azure.Documents.Resource, client.IGrape
    {
        [JsonProperty("recordid")]
        public override string Id { get; set; }

        // [JsonProperty("fields.grape_variety_proportion")]
        public decimal GrapeVarietyProportion { get; set; } 
        
        public string GrapeVariety { get; set; }

        public decimal SurfaceHa { get; set; } 
        
        public int Year { get; set; }
    }
}