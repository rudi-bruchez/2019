using Newtonsoft.Json;

namespace api_v3
{
    public class Grape : client.IGrape
    {
        [JsonProperty("recordid")]
        public string Id { get; set; }

        public string _rid {get; set; }

        // [JsonProperty("fields.grape_variety_proportion")]
        public decimal GrapeVarietyProportion { get; set; }

        public string GrapeVariety { get; set; }

        public decimal SurfaceHa { get; set; }

        public int PartitionKey { 
            get 
            {
                return this.Year;
            }
        }
        public int Year { get; set; }
    }
}