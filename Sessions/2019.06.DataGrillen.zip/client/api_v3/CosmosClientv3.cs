using System;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using Microsoft.Azure.Cosmos;
// using Microsoft.Azure.Documents.Client;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace api_v3
{
    public class MyCosmosClient
    {
        private CosmosClient _client;
        public readonly CosmosDatabase Database;
        public readonly CosmosContainer Container;

        public MyCosmosClient(string databaseName, string containerName)
        {
            CosmosConfiguration cosmosConfiguration = new CosmosConfiguration(
                accountEndPoint: "https://localhost:8081",
                accountKey: "C2y6yDjf5/R+ob0N8A7Cgv30VRDJIWEHLM+4QDU5DE2nQ9nDuVTqobD4b8mGGyPMbIZnqyMsEcaGQy67XIw/Jw==");
            // .UseCurrentRegion(LocationNames.EastUS2, LocationNames.WestUS);
 
            _client = new CosmosClient(cosmosConfiguration);
            var dbRes = _client.Databases.CreateDatabaseIfNotExistsAsync(databaseName).Result; // tpo run synchronously

            this.Database = dbRes.Database;

            PartitionKeyDefinition pk = new PartitionKeyDefinition();
            pk.Paths.Add("/Year");

            CosmosContainerSettings settings = new CosmosContainerSettings() 
            { 
                Id = containerName,
                IndexingPolicy = new IndexingPolicy()
                {
                    Automatic = false,
                    IndexingMode = IndexingMode.Lazy,
                },
                PartitionKey = pk
            };
            
            var contRes = this.Database.Containers.CreateContainerIfNotExistsAsync(settings).Result;
            this.Container = contRes.Container;
            Console.WriteLine("Database and collection validation complete");

        }

        public async Task GetAsync()
        {
            // var response = await this._client.ReadDocumentAsync(
        }

        public void DeleteAllGrapes()
        {
            // foreach (var i in this.Container.Items.GetItemIterator<Grape>())
            // this.Container.Items.DeleteItemAsync();
        }

        public void SendQuery()
        {
            // ..
        }
        public void WriteGrapes(List<Grape> grapes)
        {
            // int? throughput = this.Container.ReplaceProvisionedThroughputAsync(400).Result;
            foreach (var g in grapes)
            {
                // this.Container.Items.UpsertItemAsync<Grape>(g.PartitionKey, g);
                var r = this.Container.Items.CreateItemAsync<Grape>(new PartitionKey(g.PartitionKey), g).Result;
            }
        }

        public void ReplaceDocumentOptimistic(Grape grape)
        {
            // var ac = new AccessCondition { Condition = grape.ETag, Type = AccessConditionType.IfMatch };
            // this.Container.Items.ReplaceItemAsync(grape.Id, )
            // this._client.ReplaceItemAsync<Item>(item.id, item.id, item, new CosmosItemRequestOptions { AccessCondition = ac });   
            // _client.ReplaceDocumentAsync(grape, new RequestOptions { AccessCondition = ac });
        }
    }
}